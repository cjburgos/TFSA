import React from "react";
import { DirectionRowWrapper } from "../../components/DirectionRowWrapper";
import { BarChart2 } from "../../icons/BarChart2";
import { HelpCircle } from "../../icons/HelpCircle";
import { Size242 } from "../../icons/Size242";
import { Size243 } from "../../icons/Size243";
import { Size244 } from "../../icons/Size244";
import "./style.css";

export const NavigationButtonScreen = () => {
  return (
    <DirectionRowWrapper
      className="navigation-button-list"
      direction="row"
      navigationButtonIcon={<BarChart2 className="icon-instance-node" />}
      navigationButtonIcon1={<Size243 className="icon-instance-node" color="#757575" />}
      navigationButtonIcon2={<Size242 className="icon-instance-node" color="#757575" />}
      navigationButtonIcon3={<HelpCircle className="icon-instance-node" color="#757575" />}
      navigationButtonLabel="Balances"
      navigationButtonLabel1="Add"
      navigationButtonLabel2="Swap"
      navigationButtonLabel3="History"
      navigationButtonLabel4="Help"
      navigationButtonStateDefaultClassName="navigation-button-instance"
      override={<Size244 className="icon-instance-node" color="#2C2C2C" />}
    />
  );
};
