import { DirectionRowWrapper } from ".";

export default {
  title: "Components/DirectionRowWrapper",
  component: DirectionRowWrapper,
  argTypes: {
    direction: {
      options: ["row", "column"],
      control: { type: "select" },
    },
  },
};

export const Default = {
  args: {
    link3: true,
    link4: true,
    link5: true,
    link1: true,
    link2: true,
    direction: "row",
    className: {},
    navigationButtonLabel: "Label",
    navigationButtonStateDefaultClassName: {},
    navigationButtonLabel1: "Label",
    navigationButtonLabel2: "Label",
    navigationButtonLabel3: "Label",
    navigationButtonLabel4: "Label",
  },
};
