/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import PropTypes from "prop-types";
import React from "react";
import { Star14 } from "../../icons/Star14";
import { NavigationButton } from "../NavigationButton";
import "./style.css";

export const DirectionRowWrapper = ({
  link3 = true,
  link4 = true,
  link5 = true,
  link1 = true,
  link2 = true,
  direction,
  className,
  navigationButtonIcon = <Star14 className="star-14" color="#757575" />,
  navigationButtonLabel = "Label",
  navigationButtonStateDefaultClassName,
  override = <Star14 className="star-14" color="#2C2C2C" />,
  navigationButtonLabel1 = "Label",
  navigationButtonIcon1 = <Star14 className="star-14" color="#757575" />,
  navigationButtonLabel2 = "Label",
  navigationButtonIcon2 = <Star14 className="star-14" color="#757575" />,
  navigationButtonLabel3 = "Label",
  navigationButtonIcon3 = <Star14 className="star-14" color="#757575" />,
  navigationButtonLabel4 = "Label",
}) => {
  return (
    <div className={`direction-row-wrapper direction-${direction} ${className}`}>
      {link1 && (
        <NavigationButton
          className={`${direction === "column" ? "class" : "class-2"}`}
          direction={direction === "column" ? "row" : "column"}
          icon={navigationButtonIcon}
          label={navigationButtonLabel}
          state="default"
          type="small"
        />
      )}

      {link2 && (
        <NavigationButton
          className={navigationButtonStateDefaultClassName}
          direction={direction === "column" ? "row" : "column"}
          icon={override}
          label={navigationButtonLabel1}
          state="active"
          type="small"
        />
      )}

      {link3 && (
        <NavigationButton
          className={`${direction === "column" ? "class" : "class-2"}`}
          direction={direction === "column" ? "row" : "column"}
          icon={navigationButtonIcon1}
          label={navigationButtonLabel2}
          state="default"
          type="small"
        />
      )}

      {link4 && (
        <NavigationButton
          className={`${direction === "column" ? "class" : "class-2"}`}
          direction={direction === "column" ? "row" : "column"}
          icon={navigationButtonIcon2}
          label={navigationButtonLabel3}
          state="default"
          type="small"
        />
      )}

      {link5 && (
        <NavigationButton
          className={`${direction === "column" ? "class" : "class-2"}`}
          direction={direction === "column" ? "row" : "column"}
          icon={navigationButtonIcon3}
          label={navigationButtonLabel4}
          state="default"
          type="small"
        />
      )}
    </div>
  );
};

DirectionRowWrapper.propTypes = {
  link3: PropTypes.bool,
  link4: PropTypes.bool,
  link5: PropTypes.bool,
  link1: PropTypes.bool,
  link2: PropTypes.bool,
  direction: PropTypes.oneOf(["row", "column"]),
  navigationButtonLabel: PropTypes.string,
  navigationButtonLabel1: PropTypes.string,
  navigationButtonLabel2: PropTypes.string,
  navigationButtonLabel3: PropTypes.string,
  navigationButtonLabel4: PropTypes.string,
};
