/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import PropTypes from "prop-types";
import React from "react";
import { Star14 } from "../../icons/Star14";
import "./style.css";

export const NavigationButton = ({
  hasLabel = true,
  hasIcon = true,
  label = "Label",
  state,
  direction,
  type,
  className,
  icon = <Star14 className="star" color="#757575" />,
}) => {
  return (
    <div className={`navigation-button ${direction} ${state} ${className}`}>
      {hasIcon && <>{icon}</>}

      {hasLabel && <div className={`label state-${state} ${type}`}>{label}</div>}
    </div>
  );
};

NavigationButton.propTypes = {
  hasLabel: PropTypes.bool,
  hasIcon: PropTypes.bool,
  label: PropTypes.string,
  state: PropTypes.oneOf(["hover", "active", "default"]),
  direction: PropTypes.oneOf(["row", "column"]),
  type: PropTypes.oneOf(["medium", "small"]),
};
