import { NavigationButton } from ".";

export default {
  title: "Components/NavigationButton",
  component: NavigationButton,
  argTypes: {
    state: {
      options: ["hover", "active", "default"],
      control: { type: "select" },
    },
    direction: {
      options: ["row", "column"],
      control: { type: "select" },
    },
    type: {
      options: ["medium", "small"],
      control: { type: "select" },
    },
  },
};

export const Default = {
  args: {
    hasLabel: true,
    hasIcon: true,
    label: "Label",
    state: "hover",
    direction: "row",
    type: "medium",
    className: {},
  },
};
