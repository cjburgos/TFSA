export { Size242 } from "./Size242";
