export { Star14 } from "./Star14";
