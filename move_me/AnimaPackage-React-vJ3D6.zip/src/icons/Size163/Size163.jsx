/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import React from "react";

export const Size163 = ({ className }) => {
  return (
    <svg
      className={`size-16-3 ${className}`}
      fill="none"
      height="16"
      viewBox="0 0 16 16"
      width="16"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        className="path"
        d="M10.6666 2H14M14 2V5.33333M14 2L2.66663 13.3333M14 10.6667V14M14 14H10.6666M14 14L9.99996 10M2.66663 2.66667L5.99996 6"
        stroke="#1E1E1E"
        strokeLinecap="round"
        strokeLinejoin="round"
        strokeWidth="1.6"
      />
    </svg>
  );
};
