export { BarChart2 } from "./BarChart2";
