export { Star21 } from "./Star21";
