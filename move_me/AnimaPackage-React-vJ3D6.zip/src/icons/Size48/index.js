export { Size48 } from "./Size48";
