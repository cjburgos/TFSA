/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import React from "react";

export const Size403 = ({ className }) => {
  return (
    <svg
      className={`size-40-3 ${className}`}
      fill="none"
      height="40"
      viewBox="0 0 40 40"
      width="40"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        className="path"
        d="M26.6666 5H35M35 5V13.3333M35 5L6.66663 33.3333M35 26.6667V35M35 35H26.6666M35 35L25 25M6.66663 6.66667L15 15"
        stroke="#1E1E1E"
        strokeLinecap="round"
        strokeLinejoin="round"
        strokeWidth="3.5"
      />
    </svg>
  );
};
