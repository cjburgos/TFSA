/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import React from "react";

export const Size203 = ({ className }) => {
  return (
    <svg
      className={`size-20-3 ${className}`}
      fill="none"
      height="20"
      viewBox="0 0 20 20"
      width="20"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        className="path"
        d="M13.3334 2.5H17.5M17.5 2.5V6.66667M17.5 2.5L3.33337 16.6667M17.5 13.3333V17.5M17.5 17.5H13.3334M17.5 17.5L12.5 12.5M3.33337 3.33333L7.50004 7.5"
        stroke="#1E1E1E"
        strokeLinecap="round"
        strokeLinejoin="round"
        strokeWidth="2"
      />
    </svg>
  );
};
