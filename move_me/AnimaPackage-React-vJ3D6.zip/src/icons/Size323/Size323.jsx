/*
We're constantly improving the code you see. 
Please share your feedback here: https://form.asana.com/?k=uvp-HPgd3_hyoXRBw1IcNg&d=1152665201300829
*/

import React from "react";

export const Size323 = ({ className }) => {
  return (
    <svg
      className={`size-32-3 ${className}`}
      fill="none"
      height="32"
      viewBox="0 0 32 32"
      width="32"
      xmlns="http://www.w3.org/2000/svg"
    >
      <path
        className="path"
        d="M21.3334 4H28M28 4V10.6667M28 4L5.33337 26.6667M28 21.3333V28M28 28H21.3334M28 28L20 20M5.33337 5.33333L12 12"
        stroke="#1E1E1E"
        strokeLinecap="round"
        strokeLinejoin="round"
        strokeWidth="3"
      />
    </svg>
  );
};
